﻿using login.Resources;
using Microsoft.Extensions.DependencyInjection;

namespace login
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(new demo());
        }
    }
}